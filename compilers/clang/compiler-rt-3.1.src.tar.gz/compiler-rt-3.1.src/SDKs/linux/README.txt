This is a stub SDK for Linux. Currently, this has only been tested on i386 and
x86_64 using the Clang compiler.

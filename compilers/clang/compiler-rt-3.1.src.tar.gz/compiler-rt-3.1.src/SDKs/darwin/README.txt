The Darwin platforms are all similar enough we roll them into one SDK, and use
preprocessor tricks to get the right definitions for the few things which
diverge between OS X and iOS.
